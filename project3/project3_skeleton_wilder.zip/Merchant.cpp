// CSCI 1300 Fall 2021
// Author: Jamison Wilder
// Recitation: 215 - Luis Mieses Gomez
// Project 3

// This file defines the member functions for the Merchant class

#include "Merchant.h"
#include "Item.h"

using namespace std;

// Default constructor
Merchant::Merchant() {
    Item blankItem;

    for (int i = 0; i < MAX_INVENTORY_SPACE; i++) {
        itemStores[i] = blankItem;
        itemPrices[i] = 0;
    }
}

// Parameterized constructor
Merchant::Merchant(Item initialItemStores[], int initialItemPrices[], int arrSize) {
    Item blankItem;
    for (int i = 0; i < arrSize; i++) {
        itemStores[i] = initialItemStores[i];
        itemPrices[i] = initialItemPrices[i];
    }

    for (int i = arrSize; i < MAX_INVENTORY_SPACE; i++) {
        itemStores[i] = blankItem;
        itemPrices[i] = 0;
    }
}

/*
readStoresFile() - Reads a file and populates the merchant's inventory based on the file contents
Files can be assumed to be formatted in a specific way that works with this function. Doesn't read empty lines.

Parameters:
filename - The name of the file to be read (string)
currentStores[] - The array of items that the merchant currently has. (Item)
currentPrices[] - The array of prices for each corresponding item (int)
initialItemsStored - the initial amount of items that the merchant has stored. (int)

Returns:
The new number of items that the merchant has in his wares
If the file could not be found, returns -1
If initialItemsStored is at the max inventory space for the merchant, returns -2
If the file was empty, returns -3
*/
int Merchant::readStoresFile(string filename, Item currentStores[], int currentPrices[], int initialItemsStored) {


}

// Returns the item in the merchant's inventory at the inputted index. Returns an error item if index is invalid.
Item Merchant::getItemAt(int index) {
    Item errorItem("ITEM DOES NOT EXIST", 0, 0, 0);
    if (index < 0 || index >= MAX_INVENTORY_SPACE) {
        return errorItem;
    }
    return itemStores[index];
}

// Returns the price of an item in the merchant's inventory at the inputted index. Returns -1 if index is invalid.
int Merchant::getPriceAt(int index) {
    if (index < 0 || index >= MAX_INVENTORY_SPACE) {
        return -1;
    }
    return itemPrices[index];
}

// Sets an item in the merchant's inventory to be the specified item. Returns false if item could not be set.
bool Merchant::setItemAt(int index, Item newItem) {
    if (index < 0 || index >= MAX_INVENTORY_SPACE) {
        return false;
    }
    itemStores[index] = newItem;
    return true;
}

// Sets the price of an item in the merchant's inventory at the specified index
void Merchant::setPriceAt(int index, int newPrice) {
    if (index >= 0 && index < MAX_INVENTORY_SPACE) {
        itemPrices[index] = newPrice;
    }
}
