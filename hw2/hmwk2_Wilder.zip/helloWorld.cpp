// CS1300 Fall 2021
// Author: Jamison Wilder
// Recitation: 215 - Luis Mieses Gomez
// Homework 2 - Problem #1 - Hello World

#include <iostream>
using namespace std;

int main(){
    cout << "Hello, World!" << endl;
    return 0;
}