// CS1300 Fall 2021
// Author: Jamison Wilder
// Recitation: 215 - Luis Mieses Gomez
// Homework 2 - Problem #2 - Hello You!

#include <iostream>
using namespace std;

int main(){
    cout << "Enter your name:" << endl;
    string name;
    cin >> name;
    cout << "Hello, " << name << "!" << endl;
}